Database readme file. 

//TODO:
