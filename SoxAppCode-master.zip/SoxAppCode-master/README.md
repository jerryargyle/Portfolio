# SoxAppCode
The Swift code for the Sox Rate My Run Project

The app has the following features:
- A login and registration page
- The link to a ski resort --snowbird only at this point--
- A page with the snowbird map and a comment stream
- From the main resort page there are three buttons:
  - a button to zoom on the main map
  - a button to zoom mineral basin
  - a button to make new comments
- The comment page gives choices of runs in a picker view
- There is a text field for the comments
- A 5 star ratting system is also implmented
- Two buttons on this page can cancle or post to the database

-4/27 heroku connections have been implemented
